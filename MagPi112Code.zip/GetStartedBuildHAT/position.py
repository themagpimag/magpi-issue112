from buildhat import Motor

motor_a=Motor('A')

While True:
    print("Position: ", motor_a.get_aposition())