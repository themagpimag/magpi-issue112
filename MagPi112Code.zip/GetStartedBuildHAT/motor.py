from buildhat import Motor
motor_a = Motor('A')
motor_a.run_for_seconds(5, speed=50)